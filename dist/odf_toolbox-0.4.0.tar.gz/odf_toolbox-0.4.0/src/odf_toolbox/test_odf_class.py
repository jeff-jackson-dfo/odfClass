from pystac.utils import now_in_utc

import odfHeader
import cruiseHeader
import eventHeader
import generalCalHeader
import historyHeader
import qualityHeader
import parameterHeader
import recordHeader

# import odfUtils

odf = odfHeader.OdfHeader()

odf.set_file_specification('CTD_CAR2023573_039_1_DN.ODF')

# Add a cruise header
odf.cruise_header = cruiseHeader.CruiseHeader()
odf.cruise_header.set_cruise_number('CAR2023573')
odf.cruise_header.set_cruise_name('LABRADOR SEA')
odf.cruise_header.set_cruise_description('ATLANTIC ZONE OFF-SHELF MONITORING PROGRAM (AZOMP)')
odf.cruise_header.set_platform('CAPT JACQUES CARTIER')
odf.cruise_header.set_organization('DFO BIO')
odf.cruise_header.set_chief_scientist('MARC RINGUETTE')
odf.cruise_header.set_start_date('24-MAY-2023 00:00:00.00')
odf.cruise_header.set_end_date('12-JUN-2023 00:00:00.00')
odf.cruise_header.set_country_institute_code(1810)

# Add an event header
odf.event_header = eventHeader.EventHeader()
odf.event_header.set_data_type('CTD')
odf.event_header.set_event_number('039')
odf.event_header.set_event_qualifier1('1')
odf.event_header.set_event_qualifier2('DN')
odf.event_header.set_creation_date("02-JAN-2023 07:56:35.00")
odf.event_header.set_initial_latitude(44.5)
odf.event_header.set_initial_longitude(-63.7)
odf.event_header.set_end_latitude(-99.0)
odf.event_header.set_end_longitude(-999.0)
odf.event_header.set_min_depth(0.0)
odf.event_header.set_max_depth(100.0)
odf.event_header.set_sampling_interval(0.125)
odf.event_header.set_sounding(115.0)
odf.event_header.set_depth_off_bottom(odf.event_header.get_sounding() - odf.event_header.get_max_depth())
odf.event_header.set_event_comments("This file contains CTD data.")
odf.event_header.set_event_comments("This is the second event comment for testing purposes.")
odf.event_header.set_event_comments("The revised second event comment.", 2)

# Add a history header
odf.history_headers = list()
hh = historyHeader.HistoryHeader()
odf.history_headers.append(hh)

# Add a quality header
odf.quality_header = qualityHeader.QualityHeader()
odf.quality_header.set_quality_date('2024-12-12 12:14:46')
odf.quality_header.set_quality_tests('QUALITY CONTROL TESTS RUN')
odf.quality_header.set_quality_tests('Test 2.1: GTSPP Global Impossible Parameter Values (4)')
odf.quality_header.set_quality_tests('Test 2.2: GTSPP Regional Impossible Parameter Values (8)')
odf.quality_header.set_quality_tests('Test 2.3: GTSPP Increasing Depth (16)')
# odf.quality_header.set_quality_tests('Test 2.3: GTSPP Decreasing Depth (16)', 4)
odf.quality_header.set_quality_comments('QUALITY CODES')
odf.quality_header.set_quality_comments('0: Value has not been quality controlled')
odf.quality_header.set_quality_comments('1: Value seems to be correct')
odf.quality_header.set_quality_comments('2: Value appears inconsistent with other values')
odf.quality_header.set_quality_comments('3: Value seems doubtful')
odf.quality_header.set_quality_comments('4: Value seems erroneous')
odf.quality_header.set_quality_comments('5: Value was modified')
odf.quality_header.set_quality_comments('9: Value is missing')
# odf.quality_header.set_quality_comments('7: Unknown issue', 7)

# Add an empty General_Cal_Header for testing purposes
gch = generalCalHeader.GeneralCalHeader()
odf.general_cal_headers.append(gch)

# Add a parameter header
ph = parameterHeader.ParameterHeader()
ph.set_type("DOUB")
ph.set_name("Pressure")
ph.set_units("decibars")
ph.set_code("PRES_01")
ph.set_null_value("-99.0", 'float')
ph.set_print_field_order(1)
ph.set_print_field_width(11)
ph.set_print_decimal_places(3)
ph.set_number_null(0)
ph.set_number_valid(10)
ph.set_minimum_value(1.0)
ph.set_maximum_value(10.0)
ph.set_depth(-99.0)
ph.set_angle_of_section(-99.0)
ph.set_magnetic_variation(-99.0)
odf.parameter_headers = list()
odf.parameter_headers.append(ph)

# Add a record header
odf.record_header = recordHeader.RecordHeader()
odf.record_header.set_num_history(1)
odf.record_header.set_num_calibration(0)
odf.record_header.set_num_swing(0)
odf.record_header.set_num_param(10)
odf.record_header.set_num_cycle(250)

print("\n")
print("--------------------------------------------------------------------------------------------------------")
print("Printing the ODF file ...")
print("--------------------------------------------------------------------------------------------------------")
print("\n")
o = odf.print_object()
print(o)
